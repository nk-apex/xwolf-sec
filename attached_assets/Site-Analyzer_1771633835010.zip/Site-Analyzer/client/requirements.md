## Packages
framer-motion | sophisticated animations for scanning states and transitions
recharts | data visualization for security metrics
clsx | conditional class joining
tailwind-merge | smart class merging
date-fns | date formatting

## Notes
The app requires a dark, technical "cybersecurity" aesthetic.
Default scan target is "https://host.xwolf.space".
API endpoints follow standard REST patterns defined in shared/routes.
