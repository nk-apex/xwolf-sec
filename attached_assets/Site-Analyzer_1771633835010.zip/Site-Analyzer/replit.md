# XWOLF SEC - Security Analysis & Threat Intelligence

## Overview

XWOLF SEC is a cybersecurity web application that performs security analysis scans on target URLs. It checks for DDoS protection, scraping vulnerabilities, server configuration, and HTTP header security. Users enter a URL, the server performs a real-time analysis (DNS lookup, header inspection, bot detection), stores the results in PostgreSQL, and presents findings through a dark-themed cybersecurity dashboard.

The app follows a monorepo structure with three main directories:
- `client/` — React SPA (Vite + TypeScript)
- `server/` — Express API server (TypeScript)
- `shared/` — Shared schemas, types, and route definitions used by both client and server

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend (client/)
- **Framework**: React 18 with TypeScript, bundled by Vite
- **Routing**: Wouter (lightweight client-side router)
- **State/Data**: TanStack React Query for server state management with polling (5s interval for scan list)
- **UI Components**: shadcn/ui (new-york style) built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming, dark mode by default (cybersecurity aesthetic with green accent colors)
- **Animations**: Framer Motion for page transitions and scan states
- **Key Pages**:
  - `/` — Dashboard with scanner input, stats grid, and recent scan cards
  - `/scans/:id` — Detailed scan result view
  - `/history` and `/settings` — Placeholder routes pointing to Dashboard

### Backend (server/)
- **Framework**: Express 5 on Node.js with TypeScript (run via tsx)
- **API Pattern**: REST API with routes defined in `shared/routes.ts` using Zod schemas for validation
- **Scan Logic**: Server-side URL analysis using native `fetch` and `dns/promises` — no external scanning APIs. Checks HTTP headers, bot blocking, DDoS protection indicators (Cloudflare, etc.)
- **Dev Server**: Vite dev server middleware integrated into Express for HMR during development
- **Production**: Client is built to `dist/public/`, server is bundled with esbuild to `dist/index.cjs`

### Shared Layer (shared/)
- `schema.ts` — Drizzle ORM table definitions and Zod insert schemas for the `scans` table
- `routes.ts` — API contract definitions (method, path, input/output Zod schemas) used by both client and server

### Database
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Connection**: `node-postgres` (pg) Pool, configured via `DATABASE_URL` environment variable
- **Schema**: Single `scans` table with fields: id, url, targetIp, server, isScrapable, ddosProtected, headers (JSONB), recommendations (JSONB), createdAt
- **Migrations**: Use `npm run db:push` (drizzle-kit push) to sync schema to database

### Storage Pattern
- `server/storage.ts` defines an `IStorage` interface with `DatabaseStorage` implementation
- CRUD operations: `getScans()`, `getScan(id)`, `createScan(scan)`
- Exported singleton `storage` instance used by route handlers

### Build System
- **Dev**: `npm run dev` — runs tsx with Vite middleware for HMR
- **Build**: `npm run build` — Vite builds client, esbuild bundles server with selective dependency bundling (allowlist in `script/build.ts`)
- **Start**: `npm start` — runs the production bundle from `dist/index.cjs`
- **Type Check**: `npm run check` — TypeScript compiler check

### Path Aliases
- `@/*` → `client/src/*`
- `@shared/*` → `shared/*`
- `@assets` → `attached_assets/`

## External Dependencies

### Database
- **PostgreSQL** — Required. Connection string via `DATABASE_URL` environment variable. Used with Drizzle ORM and node-postgres pool.

### Key NPM Packages
- **drizzle-orm / drizzle-kit / drizzle-zod** — ORM, migration tooling, and Zod schema generation
- **express v5** — HTTP server framework
- **@tanstack/react-query** — Async state management on the client
- **zod** — Runtime schema validation (shared between client and server)
- **wouter** — Lightweight React router
- **framer-motion** — Animation library
- **recharts** — Data visualization (available but usage may be partial)
- **date-fns** — Date formatting utilities
- **shadcn/ui ecosystem** — Radix UI primitives, class-variance-authority, clsx, tailwind-merge, lucide-react icons
- **connect-pg-simple** — PostgreSQL session store (available in dependencies)

### Replit-Specific
- `@replit/vite-plugin-runtime-error-modal` — Error overlay in development
- `@replit/vite-plugin-cartographer` and `@replit/vite-plugin-dev-banner` — Dev-only Replit integrations

### No External APIs
- The scanning functionality is self-contained — it uses Node.js native `fetch` and `dns/promises` to analyze target URLs. No third-party security scanning APIs are used.